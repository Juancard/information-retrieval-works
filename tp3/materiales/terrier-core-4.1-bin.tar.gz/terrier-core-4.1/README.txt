Terrier - Terabyte Retriever version 4.1
Webpage: http://terrier.org 
Contact: terrier{a.}dcs.gla.ac.uk
University of Glasgow - School of Computing Science
Information Retrieval Group

Copyright (C) 2004-2015 University of Glasgow. All Rights Reserved.

Terrier is subject to the terms detailed in the Mozilla Public License
Version 1.1. The Mozilla Public License can be found in the file
LICENSE.txt or at the URL http://www.mozilla.org/MPL/MPL-1.1.html.
By using this software, you have agreed to the licence.

The source and binary forms of Terrier are subject to the following
citation license: 

By downloading Terrier, you agree to cite at least
one of these three papers describing Terrier in any kind of material 
you produce where Terrier was used to conduct search or 
experimentation, whether be it a research paper, dissertation, 
article, poster, presentation, or documentation. For more information
on publications concerning Terrier, see the Terrier Bibliography
at doc/bibliography.html. By using this software, you have agreed to the
citation licence.

In order to start using the applications that come with Terrier, or 
developping with Terrier, you may start from the documentation in 
doc/index.html. The documentation of Terrier can also be found on the 
website http://terrier.org/. You can participate on
the Terrier Forum at http://terrier.org/forum/.


